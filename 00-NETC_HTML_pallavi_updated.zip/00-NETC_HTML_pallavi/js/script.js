$(document).ready(function(){
    $('[data-toggle="popover"]').popover();

 
     //On focus event
     $('.form-control').focus(function () {
        $(this).parent().addClass('focused');
    });

    //On focusout event
    $('.form-control').focusout(function () {
        var $this = $(this);
        
        if ($this.parents('.form-line').hasClass('form-float')) {
            if ($this.val() == '') { $this.parents('.form-line').removeClass('focused'); }
        }
        else if($this.val() != ''){
        }
        else {
            $this.parents('.form-line').removeClass('focused');
        }
    });

    //On label click
    $('body').on('click', '.form-float .form-line .form-label', function () {
        $(this).parent().find('input').focus();
        $(this).removeClass("expand-content");
    });

    $('body').on('click',function () {
        $(this).removeClass("expand-content");
    });

    $(".sidebar , header").click(function(e){
        e.stopPropagation();
    });
    $('.view').click(function() {
        var view = $(this).parent().find("#password");
        $(this).toggleClass('eye-open');
        if (view.attr('type') == 'text') {
            view.attr('type', 'password');
        } else {
            view.attr('type', 'text');
        }
      });

    //Not blank form
    $('.form-control').each(function () {
        if ($(this).val() !== '') {
            $(this).parents('.form-line').addClass('focused');
        }
    });
    
   
    $(".has-submenu > a").on("click",function(e){
        e.preventDefault();
      
        if($(this).parent().hasClass('sub-active')){
            $(this).parent().removeClass("sub-active");
        }else{
            $(this).parents(".sidebar").find(".sub-active").removeClass('sub-active');
            $(this).parent().addClass("sub-active");
        }
    });
    
    $(".hamburger-icon").on("click",function(){
        $('.sidebar').toggleClass('side-expand');
    });

    // hamburger js
    $(".hamburger").on("click",function(){
        $(this).parents('body').toggleClass('expand-content');
        $(this).toggleClass("is-active");
    });
    
    // choose file 

    $(document).on('change','.up', function(){
        var names = [];
        var length = $(this).get(0).files.length;
         for (var i = 0; i < $(this).get(0).files.length; ++i) {
             names.push($(this).get(0).files[i].name);
         }
         // $("input[name=file]").val(names);
         if(length>2){
           var fileName = names.join(', ');
           $(this).closest('.form-group').find('.form-control').attr("value",length+" files selected");
         }
         else{
             $(this).closest('.form-group').find('.form-control').attr("value",names);
         }
    });

    /* -------------------------------------------------------------
            bootstrapTabControl
        ------------------------------------------------------------- */
        function bootstrapTabControl(){
            var i, items = $('.nav-link'), pane = $('.tab-pane');
            // next
            $('.nexttab').on('click', function(){
                for(i = 0; i < items.length; i++){
                    if($(items[i]).hasClass('active') == true){
                        break;
                    }
                }
                if(i < items.length - 1){
                    // for tab
                    $(items[i]).removeClass('active');
                    $(items[i+1]).addClass('active process-active');
                    // for pane
                    $(pane[i]).removeClass('show active');
                    $(pane[i+1]).addClass('show active');

                    // change title of the page on tab click
                    var x = "."+$(pane[i+1]).attr("id")+"-tab";
                    $(".main-tab").find('.active').removeClass('active');
                    $(".main-tab").find(x).addClass('active');
                   
                }

            });
            // Prev
            $('.prevtab').on('click', function(){
                for(i = 0; i < items.length; i++){
                    if($(items[i]).hasClass('active') == true){
                        break;
                    }
                }
                if(i != 0){
                    // for tab
                    $(items[i]).removeClass('active');
                    $(items[i-1]).addClass('active');
                    // for pane
                    $(pane[i]).removeClass('show active');
                    $(pane[i-1]).addClass('show active');
                }
            });
        }
        bootstrapTabControl();

        // match height

        $('.equal-height').matchHeight();

        
});
